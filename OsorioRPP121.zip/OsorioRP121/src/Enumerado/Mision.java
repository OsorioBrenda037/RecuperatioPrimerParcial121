
package Enumerado;

public enum Mision {
    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO;
}
