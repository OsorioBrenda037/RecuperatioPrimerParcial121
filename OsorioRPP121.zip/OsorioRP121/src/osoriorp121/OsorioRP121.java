
package osoriorp121;

import Clases.AgenciaEspacial;
import Clases.Carguero;
import Clases.CruceroEstelar;
import Clases.NaveExploracion;
import Enumerado.Mision;
import Excepciones.NaveYaExisteException;

public class OsorioRP121 {

    public static void main(String[] args) {
        AgenciaEspacial a1 = new AgenciaEspacial();
        
        NaveExploracion n1 = new NaveExploracion("Exploradora 0001", 100, 2020, Mision.CARTOGRAFIA);
        NaveExploracion n2 = new NaveExploracion("Exploradora 0002", 450, 2023, Mision.INVESTIGACION);
        NaveExploracion n3 = new NaveExploracion("Exploradora 0003", 50, 2019, Mision.CONTACTO);
        
        //REPETIDO
        NaveExploracion n4 = new NaveExploracion("Exploradora 0001", 100, 2020, Mision.CARTOGRAFIA);
        
        
        Carguero c1 = new Carguero("Carguero 0001", 237, 2015, 150);
        Carguero c2 = new Carguero("Carguero 0002", 300, 2018, 400.2);
        Carguero c3 = new Carguero("Carguero 0003", 500, 2015, 397.5);
        
        //REPETIDO
        Carguero c4 = new Carguero("Carguero 0001", 237, 2015, 150);
        
        CruceroEstelar ce1 = new CruceroEstelar("Crucero 0001", 600, 2010, 5000);
        CruceroEstelar ce2 = new CruceroEstelar("Crucero 0002", 800, 2020, 15000);
        CruceroEstelar ce3 = new CruceroEstelar("Crucero 0003", 500, 2009, 4500);
        
        //REPETIDO
        CruceroEstelar ce4 = new CruceroEstelar("Crucero 0001", 600, 2010, 5000);
        
        try {
            a1.agregarNave(n1);
            a1.agregarNave(n2);
            a1.agregarNave(n3);
            
            //AGREGAR REPETIDO
            //a1.agregarNave(n4);
            
            a1.agregarNave(c1);
            a1.agregarNave(c2);
            a1.agregarNave(c3);
            
            //AGREGAR REPETIDO
            //a1.agregarNave(c4);
            
            a1.agregarNave(ce1);
            a1.agregarNave(ce2);
            a1.agregarNave(ce3);
            
            //AGREGAR REPTIDO
            //a1.agregarNave(ce4);
        } catch (NaveYaExisteException e) {
            System.out.println(e.getMessage());
        }
        
        a1.mostrarNaves();
        System.out.println();
        
        a1.iniciarExploracion();
        
    }
    
}
