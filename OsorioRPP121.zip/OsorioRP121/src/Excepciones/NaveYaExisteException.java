package Excepciones;

public class NaveYaExisteException extends RuntimeException {
    private static final String MENSAJE = "La nave ya se encuentra en la agencia.";
    
    public NaveYaExisteException() {
        super(MENSAJE);
    }
}
