
package Clases;

public class CruceroEstelar extends Nave{
    private int capacidadPasajeros;

    public CruceroEstelar(String nombre, int capacidadTripulacion, int anioLanzamiento, int capacidadPasajeros) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.capacidadPasajeros = capacidadPasajeros;
    }

    @Override
    public String toString() {
        return "CruceroEstelar{" + super.toString() + ", capacidadPasajeros=" + capacidadPasajeros + '}';
    }
}
