
package Clases;

import Interface.Explorable;

public class Carguero extends Nave implements Explorable {
    
    private double capacidadToneladas;
    private static final double CAPACIDAD_MINIMA = 100.0;
    private static final double CAPACIDAD_MAXIMA = 500.0;
    
    public Carguero(String nombre, int capacidadTripulacion, int anioLanzamiento, double capacidadToneladas) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.capacidadToneladas = setCapacidadPeso(capacidadToneladas);
    }

    @Override
    public void explorar() {
        System.out.println("El carguero " + getNombre() + " comienza su exploracion...");
    }

    @Override
    public String toString() {
        return "Carguero{" + super.toString() + ", capacidadToneladas=" + capacidadToneladas + '}';
    }
    
    private double setCapacidadPeso(double toneladas) {
        if (toneladas < CAPACIDAD_MINIMA || toneladas > CAPACIDAD_MAXIMA) {
            throw new IllegalArgumentException("La capacidad de toneladas es entre 100 y 500.");
        }
        return this.capacidadToneladas = toneladas;
    }
    
}
