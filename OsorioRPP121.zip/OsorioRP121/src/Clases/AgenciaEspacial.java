
package Clases;

import Excepciones.NaveYaExisteException;
import Interface.Explorable;
import java.util.ArrayList;
import java.util.List;

public class AgenciaEspacial {
    private List<Nave> naves;
    
    public AgenciaEspacial() {
        naves = new ArrayList<>();
    }
    
    public void agregarNave(Nave nave) {
        if (nave == null) {
            throw new NullPointerException("No se puede agregar un objeto que no existe");
        }
        
        if (naves.contains(nave)) {
            throw new NaveYaExisteException();
        }
        naves.add(nave);
    }
    
    public void mostrarNaves() {
        for (Nave n: naves) {
            System.out.println(n);
        }
    }
    
    public void iniciarExploracion() {
        for (Nave n: naves) {
            if (n instanceof Explorable ne) {
                ne.explorar();
            }
            else {
                System.out.println("El crucero " + n.getNombre() + " no puede realizar esta mision (solo transporte de pasajeros)");
            }
        }
    }
}
