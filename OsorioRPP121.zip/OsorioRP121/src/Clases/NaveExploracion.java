
package Clases;

import Enumerado.Mision;
import Interface.Explorable;

public class NaveExploracion extends Nave implements Explorable {
    private Mision tipoMision;

    public NaveExploracion(String nombre, int capacidadTripulacion, int anioLanzamiento, Mision tipoMision) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.tipoMision = tipoMision;
    }

    @Override
    public void explorar() {
        System.out.println("La nave " + getNombre() + " comienza su exploracion...");
    }

    @Override
    public String toString() {
        return "NaveExploracion{"+ super.toString() + ", tipoMision=" + tipoMision + '}';
    } 
}
