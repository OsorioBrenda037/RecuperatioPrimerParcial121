
package Interface;

public interface Explorable {
    void explorar();
}
